#ifndef __bar__
#define __bar__

#include <stdio.h>

void bar_print_hello();
void bar_print_goodbye();


#endif
