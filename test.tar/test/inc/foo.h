#ifndef __foo__
#define __foo__

#include <stdio.h>

void foo_print_hello();
void foo_print_goodbye();


#endif
