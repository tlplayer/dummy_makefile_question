#include "foo.h"

void foo_print_hello()
{
    printf("Hello\n");
}
