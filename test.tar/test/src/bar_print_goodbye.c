#include "bar.h"

void bar_print_goodbye()
{
    printf("Goodbye\n");
}
