#include "bar.h"

void bar_print_hello()
{
    printf("Hello\n");
}
