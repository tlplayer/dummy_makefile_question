#include "bar.h"
#include "foo.h"

int main()
{
    foo_print_hello();
    foo_print_goodbye();
    bar_print_hello();
    bar_print_goodbye();
    return 0;
}
