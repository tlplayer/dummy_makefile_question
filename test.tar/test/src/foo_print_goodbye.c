#include "foo.h"

void foo_print_goodbye()
{
    printf("Goodbye\n");
}
